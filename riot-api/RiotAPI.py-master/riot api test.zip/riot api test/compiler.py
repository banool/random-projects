import py_compile
py_compile.compile('riot api stat test.py')
