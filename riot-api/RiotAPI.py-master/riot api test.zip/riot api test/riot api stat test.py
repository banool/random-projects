# Nooly "Nools" Noolsworth
# Date Created: 06/06/2014
# Date Modified: 07/06/2014
# PEP8 compliant save for line length in places

"""
Originally used someone else's python calls for the Riot API, but
that was outdated based on region specific endpoints and version numbers.

Can get the summoner ID for a summoner name and use it for future operations.
It also saves it to a database so if further requests are made for that
summoner, the ID is already there, avoiding another call to the API.

Currently it only tells you one specific piece of information, at this stage
being their maximum time played in a ranked game on a specific champ.
However this can be easily changed just by using a different dictionary index
in the data pulled from the inital stats API call.
"""

#from riotapi import RiotAPI
from requests import get
from ast import literal_eval
import cPickle as pickle

summ_version = "v1.4"
stats_version = "v1.3"
stat_dat_version = "v1.2"
key = "3b39cc75-4cb2-4a2e-9a46-a3f44ebcf532"


def summoner_id_find(summoner, region, call_start):

    known_ids_dict = pickle.load(open("known_ids.p", "rb"))

    summ_id = 0

    if known_ids_dict.get(summoner) is not None:
        summ_id = known_ids_dict.get(summoner)
        print "Using summoner ID value in database: " + str(summ_id)
    else:
        print "Searching up summoner ID, not in database."
        url_call_summ_id = call_start + summ_version + "/" + "summoner/by-name/" + summoner + "?api_key=" + key
        summ_id_data = get(url_call_summ_id)
        summ_id_code = summ_id_data.status_code
        if summ_id_code == 200:
            print "Good call, got response code 200."
            # Now we know we have good data, we can append the new summoner and respective ID to the dictionary.
            summ_id = literal_eval(str(summ_id_data.text))[summoner]["id"]
            print "Summoner ID retrieved for " + str(summoner) + ": " + str(summ_id)
            known_ids_dict[summoner] = summ_id
            # This then writes the dictionary back to the file as a string
            pickle.dump(known_ids_dict, open("known_ids.p", "wb"))
        else:
            print "Receieved error " + str(summ_id_code) + ", perhaps a non-existent Summoner. Starting again..."
            summoner_id_find()

    return summ_id


def summoner_ranked_champ_stats(summ_id, region, season, call_start):
    # Starts the call for the players data on all champs.
    url_call = call_start + stats_version + "/stats/by-summoner/" + str(summ_id) + "/ranked?season=SEASON" + str(season) + "&api_key=" + key
    stats_data = get(url_call)
    stats_code = stats_data.status_code
    if stats_code == 200:
        # No need for good call message as this is a static call, should work 100% of the time.
        # Starts call for a champ to ID translation.
        champ = str(raw_input("Which champ did you want your stats for? ")).lower().title()
        url_call = "https://" + region + ".api.pvp.net/api/lol/static-data/" + region + "/" + stat_dat_version + "/champion?api_key=" + key
        stat_dat_data = get(url_call)
        stat_dat_code = stat_dat_data.status_code
        champ_id = 0
        if stat_dat_code == 200:
            # If the request was made properly, this finds the champ ID from the data.
            print "Another good call, got response code 200."
            try:
                print str(champ) + ", " + literal_eval(stat_dat_data.text)["data"][champ]["title"]
                champ_id = literal_eval(stat_dat_data.text)["data"][champ]["id"]
                print "ID: " + str(champ_id)
            except KeyError:
                print "That champion doesn't exist, try again."
                summoner_stats_func(summ_id, summoner, region, season, call_start)
            except:
                sys.exit("Something went wrong, terminating...")
        else:
            print "Receieved error " + str(stat_dat_code) + ", perhaps a non-existent Summoner. Starting again..."
            summoner_stats_func()
        found = 0
        for i in literal_eval(stats_data.text)["champions"]:
            if i["id"] == champ_id:
                found = 1
                stat_wanted = str(raw_input("What data did you want to know?\n(Try: totalDoubleKills to start with) "))
                print i["stats"][stat_wanted]
                done = 0
                while done != 1:
                    again = str(raw_input("Do you want to know more for this champ? ")).lower()
                    if again == "yes" or again == "y":
                        try:
                            stat_wanted = str(raw_input("What data did you want to know? "))
                            print i["stats"][stat_wanted]
                        except KeyError:
                            print "That was an invalid stat call, try something else."
                            pass
                        except:
                            print "Dat shit dun fukt"
                    else:
                        done = 1
        if found == 0:
            print "You have not played this champ in ranked this season.\nTry again."
            summoner_ranked_champ_stats(summ_id, region, season, call_start)
    else:
        print "Receieved error " + str(stats_code) + ", perhaps a non-existent Summoner. Starting again..."
        summoner_stats_func()
    print "Thanks for using, re-run the program for a different champion if you want.\nTry typing 'main()' without the quotation marks."


def summoner_general_stats(summ_id, summoner, region, season, call_start):
    mode_wanted_dict = {"ranked solo 5s": "RankedSolo5x5", "unranked 5s": "Unranked", "unranked 3s": "Unranked3x3", "urf": "URF"}
    url_call = call_start + stats_version + "/stats/by-summoner/" + str(summ_id) + "/summary?season=SEASON" + str(season) + "&api_key=" + key
    stats_data = get(url_call)
    stats_code = stats_data.status_code
    if stats_code == 200:
        print "Good call, got response code 200."
        mode_wanted = str(raw_input("\nWhich game mode did you want data for?\nOptions: ranked solo 5s, unranked 5s, unranked 3s, urf: "))
        if mode_wanted_dict.get(mode_wanted) is not None:
            print "Good game mode selection: " + mode_wanted_dict[mode_wanted]
            for mode in literal_eval(stats_data.text)["playerStatSummaries"]:
                if mode['playerStatSummaryType'] == mode_wanted_dict[mode_wanted]:
                    done = 0
                    while done != 1:
                        stat_wanted = str(raw_input("\nWhat stat did you want to know about your overall summoner profile?\nOptions: wins, " + str(mode["aggregatedStats"].keys()) + "\nStat wanted: "))
                        try:
                            if stat_wanted == "wins":
                                print mode["wins"]
                            else:
                                print mode['aggregatedStats'][stat_wanted]
                            again = str(raw_input("Did you want to know something else? ")).lower()
                            if again == "yes" or done == "y":
                                done = 0
                            else:
                                done = 1
                        except KeyError:
                            print "That was an invalid stat, try again."
        else:
            print "That was an invalid mode, try again."
            summoner_general_stats(summ_id, summoner, region, season, call_start)
        print "Thanks for using, re-run the program for another summoner if you want.\nTry typing 'main()' without the quotation marks."


def main():
    summoner = (str(raw_input("Enter summoner name: "))).lower()
    region = (str(raw_input("What region? "))).lower()
    season = str(raw_input("Which season? (3 or 4) "))

    ok = 0
    while ok != 1:
        try:
            if 3 <= int(season) <= 4:
                ok = 1
                break
            else:
                season = str(raw_input("Invalid season. Which season? (3 or 4) "))
        except:
            print "You probably entered a letter, you done fucked it."
            season = str(raw_input("Invalid season. Which season? (3 or 4) "))

    call_start = "https://" + region + ".api.pvp.net/api/lol/" + region + "/"

    summ_id_m = summoner_id_find(summoner, region, call_start)
    type_call = int(raw_input("\nDid you want your stats for a specific champ (ranked only for this function)? (1)\nOr overall stats on your summoner profile? (2) "))
    if type_call == 1:
        # If they called for their specific stats on a champ.
        summoner_ranked_champ_stats(summ_id_m, region, season, call_start)
    elif type_call == 2:
        # If they called for general stats.
        summoner_general_stats(summ_id_m, summoner, region, season, call_start)
    else:
        print "That was an invalid choice, choose 1 or 2 please."
        main()

main()

"""
old shit
riot_api = RiotAPI(key)

get_req = ("https://oce.api.pvp.net/api/lol/oce/v1.4/summoner/by-name/Banool?api_key=" + key)
print get_req

swag = get(get_req)
print swag

print riot_api.get_summoner_by_name("Banool", "oce")
"""
